document.getElementById('btnComprar').addEventListener('click', () => {
    alert('¡Producto agregado al carrito! No necesitas pagar ahora.');
});
